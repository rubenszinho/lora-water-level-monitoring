//Libraries for LoRa
#include <SPI.h>
#include <LoRa.h>

//Libraries for MQTT connection
#include <WiFi.h>
#include <PubSubClient.h>


//Libraries for OLED Display
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

//configurating wifi specs
const char* ssid = "POCO F3";
const char* password = "piruzinho";
const char* passwordlab = "L2sdpc2017";


const char* mqttServer = "andromeda.lasdpc.icmc.usp.br";
const char* topic = "enoe/nivelrio";
const int mqttPort = 7046;

const char* vmuser = "giot06";
const char* vmpassword = "YhW6Mt3O";

int qos = 1; //quality of service for MQTT publishing (1 = at least once)

WiFiClient espClient;
PubSubClient client(espClient);

//define the pins used by the LoRa transceiver module
#define SCK 5
#define MISO 19
#define MOSI 27
#define SS 18
#define RST 14
#define DIO0 26

//433E6 for Asia
//866E6 for Europe
//915E6 for North America
#define BAND 915E6

//OLED pins
#define OLED_SDA 4
#define OLED_SCL 15 
#define OLED_RST 16
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RST);

String LoRa_Data;
String Data_temp;

void setup() { 
  //initialize Serial Monitor
  Serial.begin(9600);
  
  //connecting to wifi
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  //set server
  client.setServer(mqttServer, mqttPort);
client.publish(topic, LoRa_Data.c_str(), qos)
  
  //reset OLED display via software
  pinMode(OLED_RST, OUTPUT);
  digitalWrite(OLED_RST, LOW);
  delay(20);
  digitalWrite(OLED_RST, HIGH);
  
  //initialize OLED
  Wire.begin(OLED_SDA, OLED_SCL);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3c, false, false)) { // Address 0x3C for 128x32
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }

  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0,0);
  display.print("LORA CARECA RECEIVER ");
  display.display();

  Serial.println("LoRa CARECA Receiver Test");
  
  //SPI LoRa pins
  SPI.begin(SCK, MISO, MOSI, SS);
  //setup LoRa transceiver module
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(BAND)) {
    Serial.println("Starting LoRa failed!");
    while (1);
  }
  Serial.println("LoRa Initializing OK!");
  display.setCursor(0,10);
  display.println("LoRa Initializing OK!");
  display.display();  
}


//handle problems with connection
void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect("ESP32giot6", vmuser, vmpassword)) {
      Serial.println("connected");
      
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 3 seconds before retrying
      delay(3000);
    }
  }
}

void loop() {

  //try to parse packet
  int packetSize = LoRa.parsePacket();
  if (packetSize) {
    //received a packet
    Serial.print("Received CARECA packet ");

    //read packet
    while (LoRa.available()) {
      LoRa_Data = LoRa.readString();
      Serial.print(LoRa_Data);
    }

    //print RSSI of packet
    int rssi = LoRa.packetRssi();
    Serial.print(" with RSSI ");    
    Serial.println(rssi);

   // Dsiplay information
   display.clearDisplay();
   display.setCursor(0,0);
   display.print("LORA RECEIVER");
   display.setCursor(0,20);
   display.print("Received packet:");
   display.setCursor(0,30);
   display.print(LoRa_Data);
   display.setCursor(0,40);
   display.print("RSSI:");
   display.setCursor(30,40);
   display.print(rssi);
   display.display();   
  }


  // Check if the client is connected to the MQTT broker
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  //Publish Data received to Server using MQTT
  if (LoRa_Data != Data_temp) {
    client.publish(topic, LoRa_Data.c_str(), qos);
    Serial.println(LoRa_Data.c_str());
    Data_temp = LoRa_Data;
  } else {
    Serial.println("Waiting for update from sender");
  }

}

